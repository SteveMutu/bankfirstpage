var navbarToggler = document.getElementById("btn");
var navigationDiv = document.querySelector(".mobileNav");
var body = document.querySelector("body");
var show = document.getElementById("show");
var hide = document.getElementById("hide");

navbarToggler.addEventListener("click", displayNav);

function displayNav() {
    navigationDiv.classList.toggle("display");
    body.classList.toggle("overflow");
    show.classList.toggle("display");
    show.classList.toggle("hide");
    hide.classList.toggle("hide");
    hide.classList.toggle("display");
}


document.addEventListener("DOMContentLoaded", function () {
  const floatingButton = document.getElementById("floatingButton");
  const voiceChatBtn = document.getElementById("voiceChatBtn");
  const videoChatBtn = document.getElementById("videoChatBtn");
  const messageChatBtn = document.getElementById("messageChatBtn");

  let isFloatingButtonOpen = false;

  floatingButton.addEventListener("click", () => {
    if (isFloatingButtonOpen) {
      closeFloatingButton();
    } else {
      openFloatingButton();
    }
  });

  function openFloatingButton() {
    floatingButton.classList.add("open");
    isFloatingButtonOpen = true;
  }

  function closeFloatingButton() {
    floatingButton.classList.remove("open");
    isFloatingButtonOpen = false;
  }

  voiceChatBtn.addEventListener("click", () => {
    closeFloatingButton();
  });

  videoChatBtn.addEventListener("click", () => {
    closeFloatingButton();
  });

  messageChatBtn.addEventListener("click", () => {
    closeFloatingButton();
  });
});
